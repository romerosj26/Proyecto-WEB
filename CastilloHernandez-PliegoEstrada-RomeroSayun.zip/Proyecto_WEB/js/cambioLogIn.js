document.getElementById("formulario-login-link").addEventListener("click", function (e) {
            e.preventDefault();
            document.getElementById("formulario-login").style.display = "block";
            document.getElementById("formulario-registro").style.display = "none";
            this.classList.add("active");
            document.getElementById("formulario-registro-link").classList.remove("active");
        });
        document.getElementById("formulario-registro-link").addEventListener("click", function (e) {
            e.preventDefault();
            document.getElementById("formulario-registro").style.display = "block";
            document.getElementById("formulario-login").style.display = "none";
            this.classList.add("active");
            document.getElementById("formulario-login-link").classList.remove("active");
        });