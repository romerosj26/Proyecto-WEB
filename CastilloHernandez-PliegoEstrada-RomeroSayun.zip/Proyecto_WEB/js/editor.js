const lienzo = document.getElementById("lienzo");
const fondo = document.getElementById("fondo");

let limitesLienzo ={
    x: 0,
    y: 0,
    ancho: 700,
    alto: 400
};

const espacioExtra = 5;

let temporizadorClic;

const btnRelleno = document.getElementById("btn-relleno");
const btnContorno = document.getElementById("btn-contorno");
const btnEditarTexto = document.getElementById("btn-editar-texto");
const btnCerrarContorno = document.getElementById("btn-cerrar-contorno");
const btnCerrarRelleno = document.getElementById("btn-cerrar-relleno");
const btnCerrarTexto = document.getElementById("btn-cerrar-texto");

const panelRelleno = document.getElementById("panel-editarRelleno");
const panelContorno = document.getElementById("panel-editarContorno");
const panelTexto = document.getElementById("panel-editarTexto");
const panelesEditar = document.querySelectorAll("#panel-editarContorno, #panel-editarRelleno, #panel-editarTexto");

let panelActivo = null;

const botones = document.querySelectorAll(
    ".simbolos button:not(#btn-conectar)"
);

let cantidadElementos = 0;
let simboloSeleccionado = null;
let conexionSeleccionada = null;

const botonEliminar = document.getElementById("btn-eliminar");

const capaConexiones = document.getElementById("conexiones");
const botonConectar = document.getElementById("btn-conectar");

let siguienteId = 1;
let modoConexion = false;
let origenConexion = null;
let conexionPendiente = null;

const listaConexiones = [];

botonConectar.addEventListener("click", function () {
    if (conexionPendiente !== null) {
        conexionPendiente.linea.remove();
        if (origenConexion !== null) {
            origenConexion.firstElementChild.setAttribute("stroke-width", 2);
        }
        conexionPendiente = null;
        origenConexion = null;
        modoConexion = false;
        return;
    }

    const linea = crearElementoSVG("line", {
        stroke: "var(--flecha)",
        x1: 350,
        y1: 300,
        x2: 450,
        y2: 300,
        "stroke-width": 1,
        "marker-end": "url(#punta-flecha)",
        "pointer-events": "none"
    });

    capaConexiones.appendChild(linea);
    conexionPendiente = { linea: linea };
    modoConexion = true;
});

const SVG_NS = "http://www.w3.org/2000/svg";

botones.forEach(function (boton) {
    boton.addEventListener("click", function () {
        const tipo = boton.dataset.tipo;

        agregarSimbolo(tipo);
    });
});

function crearElementoSVG(etiqueta, atributos) {
    const elemento = document.createElementNS(
        SVG_NS,
        etiqueta
    );

    Object.entries(atributos).forEach(function ([nombre, valor]) {
        elemento.setAttribute(nombre, valor);
    });

    return elemento;
}

function agregarSimbolo(tipo) {
    const columna = cantidadElementos % 2;
    const fila = Math.floor(cantidadElementos / 2);

    const x = 250 + columna * 400;
    const y = 70 + fila * 130;

    const grupo = crearElementoSVG("g", {
        class: "simbolo",
        "data-tipo": tipo,
        "data-id": `simbolo-${siguienteId}`,
        transform: `translate(${x} ${y})`
    });

    siguienteId++;

    let figura;

    if (tipo === "inicio" || tipo === "fin") {
        figura = crearElementoSVG("ellipse", {
            cx: 0,
            cy: 0,
            rx: 35,
            ry: 20,
            fill: tipo === "inicio" ? "#dcfce7" : "#fee2e2",
            stroke: tipo === "inicio" ? "#16a34a" : "#dc2626",
            "stroke-width": 2
        });
    } else if (tipo === "proceso") {
        figura = crearElementoSVG("rect", {
            x: -50,
            y: -20,
            width: 100,
            height: 40,
            rx: 4,
            fill: "#dbeafe",
            stroke: "#2563eb",
            "stroke-width": 2
        });
    } else if (tipo === "decision"){
        figura = crearElementoSVG("polygon", {
            points: "-55,0 0,-25 55, 0 0,25",
            fill: "#dbeafe",
            stroke: "#2563eb",
            "stroke-width": 2
        });
    } else if (tipo === "entrada"){
        figura = crearElementoSVG("polygon", {
            points: "-45,-20 65,-20 45,20 -65,20",
            fill: "#e0e7ff",
            stroke: "#4f46e5",
            "stroke-width": 2
        });
    } else if (tipo === "documento") {
        figura = crearElementoSVG("path", {
            d: "M -70,-20 H 70 V 20 C 50,10 35,30 15,20 S -20,30 -40,20 S -60,30 -70,20 Z",
            fill: "#f3e8ff",
            stroke: "#9333ea",
            "stroke-width": 2
        });
    } else if (tipo === "flecha") {
        figura = crearElementoSVG("line", {
            stroke: "#475569",
            x1: 10,   
            y1: 50,   
            x2: 170,  
            y2: 50,
            "stroke-width": 2,
            "marker-end": "url(#punta-flecha)",
        });
    } else {
        return;
    }

    const texto = crearElementoSVG("text", {
        x: 0,
        y: 5,
        "text-anchor": "middle",
        "font-size": 16,
        fill: "#1f2937",
        "pointer-events": "auto"
    });

    const etiquetas ={
        "inicio": "INICIO",
        "fin": "FIN",
        "proceso": "Proceso",
        "decision": "Condición",
        "documento": "Documento",
    };

    texto.textContent = etiquetas[tipo];

    grupo.appendChild(figura);
    grupo.appendChild(texto);

    grupo.addEventListener("click", function (evento) {
        evento.stopPropagation();

        if (modoConexion) {
            // Seleccionar el origen.
            if (origenConexion === null) {
                origenConexion = grupo;

                grupo.classList.add("origen-conexion");
                // figura.setAttribute("stroke-width", 4);
                return;
            }

            // No permitir conectar un símbolo consigo mismo.
            if (origenConexion === grupo) {
                grupo.classList.remove("origen-conexion");
                origenConexion = null;
                return;
            }

            crearConexion(origenConexion, grupo, conexionPendiente.linea);

            // Quitar el resaltado del origen.
            const figuraOrigen = origenConexion.firstElementChild;
            figuraOrigen.classList.remove("origen-conexion");

            origenConexion = null;
            conexionPendiente = null;
            modoConexion = false;

            return;
        }

        // Si no estamos conectando, seleccionar el símbolo.
        seleccionarSimbolo(grupo);
    });

    texto.style.cursor = "text";

    // Modificar texto del símbolo al hacer doble clic sobre él.
    grupo.addEventListener("dblclick", function (evento) {
        evento.preventDefault();
        evento.stopPropagation();

        const nuevoTexto = prompt(
            "Escribe el texto del símbolo:",
            texto.textContent
        );

        if (nuevoTexto !== null && nuevoTexto.trim() !== "") {
            texto.textContent = nuevoTexto.trim();
        }
    });

    hacerMovible(grupo);

    lienzo.appendChild(grupo);

    cantidadElementos++;
}

function seleccionarSimbolo(grupo) { 
    if (simboloSeleccionado !== null) {
        simboloSeleccionado.classList.remove("seleccionado");
    }
    if (conexionSeleccionada !== null) {
        conexionSeleccionada.linea.setAttribute("stroke-width", 2);
        conexionSeleccionada = null;
    }

    simboloSeleccionado = grupo;

    if (simboloSeleccionado !== null) {
        simboloSeleccionado.classList.add("seleccionado");
    }

    actualizarPanelEditar();
    habilitarBotonesEdicion();
}

document.addEventListener("click", (evento) => {
    const elemento = evento.target;
    const dentroDeSimbolo = elemento.closest(".simbolo");
    const dentroDePanel = elemento.closest(".panel-editar");
    const dentroDeBotones = elemento.closest("#btn-relleno, #btn-contorno, #btn-editar-texto");

    if (dentroDeSimbolo || dentroDePanel || dentroDeBotones) {
        return;
    }

    if (simboloSeleccionado !== null) {
        simboloSeleccionado.classList.remove("seleccionado");

        simboloSeleccionado = null;

        actualizarPanelEditar();
        habilitarBotonesEdicion();
    }

    if (conexionSeleccionada !== null) {
        conexionSeleccionada.linea.setAttribute("stroke-width", 2);

        conexionSeleccionada = null;
    }
});

function obtenerCoordenadas(evento) {
    const punto = lienzo.createSVGPoint();

    punto.x = evento.clientX;
    punto.y = evento.clientY;

    return punto.matrixTransform(
        lienzo.getScreenCTM().inverse()
    );
}

function hacerMovible(grupo) {
    grupo.style.cursor = "grab";
    grupo.style.touchAction = "none";

    let desplazamientoX = 0;
    let desplazamientoY = 0;
    let arrastrando = false;

    grupo.addEventListener("pointerdown", function (evento) {
        if (evento.button !== 0) return;

        evento.preventDefault();
        evento.stopPropagation();

        const punto = obtenerCoordenadas(evento);

        const transformacion = grupo.transform.baseVal.consolidate();

        const matriz = transformacion
            ? transformacion.matrix
            : lienzo.createSVGMatrix();

        desplazamientoX = punto.x - matriz.e;
        desplazamientoY = punto.y - matriz.f;

        arrastrando = true;
        grupo.style.cursor = "grabbing";

        grupo.setPointerCapture(evento.pointerId);
    });

    grupo.addEventListener("pointermove", function (evento) {
        if (!arrastrando) return;

        const punto = obtenerCoordenadas(evento);

        let x = punto.x - desplazamientoX;
        let y = punto.y - desplazamientoY;

        // Limitar el movimiento al área del lienzo.
        const limiteX = 85;
        const limiteY = 40;

        const anchoLienzo = 700;
        const altoLienzo = 600;

        // x = Math.max(limiteX, Math.min(x, anchoLienzo - limiteX));
        // y = Math.max(limiteY, Math.min(y, altoLienzo - limiteY));

        grupo.setAttribute(
            "transform",
            `translate(${x} ${y})`
        );

        expandirLienzo();
        actualizarConexiones();
    });

    function terminarArrastre(evento) {
        if (!arrastrando) return;

        arrastrando = false;
        actualizarConexiones();

        grupo.style.cursor = "grab";

        if (grupo.hasPointerCapture(evento.pointerId)) {
            grupo.releasePointerCapture(evento.pointerId);
        }
    }

    grupo.addEventListener("pointerup", terminarArrastre);
    grupo.addEventListener("pointercancel", terminarArrastre);
}

function crearConexion(origen, destino, linea) {
    const hitArea = crearElementoSVG("line", {
        stroke: "transparent",
        "stroke-width": 14,
        "stroke-linecap": "round",
        "pointer-events": "stroke",
        cursor: "grab"
    });

    capaConexiones.appendChild(hitArea);

    const conexion = {
        origen: origen,
        destino: destino,
        linea: linea,
        hitArea: hitArea,
        anclaOrigen: obtenerAncla(origen, destino),
        anclaDestino: obtenerAncla(destino, origen)
    };

    listaConexiones.push(conexion);

    hitArea.addEventListener("click", function (evento) {
        if (modoConexion) return;

        evento.stopPropagation();
        seleccionarConexion(conexion);
    });

    let arrastrando = false;
    let ultimoPunto = null;

    hitArea.addEventListener("pointerdown", function (evento) {
        if (evento.button !== 0 || modoConexion) return;

        evento.preventDefault();
        evento.stopPropagation();
        seleccionarConexion(conexion);

        arrastrando = true;
        ultimoPunto = obtenerCoordenadas(evento);
        hitArea.style.cursor = "grabbing";
        hitArea.setPointerCapture(evento.pointerId);
    });

    hitArea.addEventListener("pointermove", function (evento) {
        if (!arrastrando) return;

        const punto = obtenerCoordenadas(evento);
        const deltaX = punto.x - ultimoPunto.x;
        const deltaY = punto.y - ultimoPunto.y;
        const limitesOrigen = obtenerLimites(conexion.origen);
        const limitesDestino = obtenerLimites(conexion.destino);

        conexion.anclaOrigen = limitarAncla({
            x: conexion.anclaOrigen.x + deltaX / limitesOrigen.hw,
            y: conexion.anclaOrigen.y + deltaY / limitesOrigen.hh
        });
        conexion.anclaDestino = limitarAncla({
            x: conexion.anclaDestino.x + deltaX / limitesDestino.hw,
            y: conexion.anclaDestino.y + deltaY / limitesDestino.hh
        });

        ultimoPunto = punto;
        actualizarConexiones();
    });

    function terminarArrastre(evento) {
        if (!arrastrando) return;

        arrastrando = false;
        hitArea.style.cursor = "grab";

        if (hitArea.hasPointerCapture(evento.pointerId)) {
            hitArea.releasePointerCapture(evento.pointerId);
        }
    }

    hitArea.addEventListener("pointerup", terminarArrastre);
    hitArea.addEventListener("pointercancel", terminarArrastre);

    actualizarConexiones();
}

function seleccionarConexion(conexion) {
    if (simboloSeleccionado !== null) {
        simboloSeleccionado.classList.remove("seleccionado");
        simboloSeleccionado = null;
        // simboloSeleccionado.firstElementChild.setAttribute("stroke-width", 2);
        // simboloSeleccionado = null;
    }

    if (conexionSeleccionada !== null) {
        conexionSeleccionada.linea.setAttribute("stroke-width", 2);
    }

    conexionSeleccionada = conexion;
    conexionSeleccionada.linea.setAttribute("stroke-width", 4);
}

function obtenerAncla(grupo, otroGrupo) {
    const limites = obtenerLimites(grupo);
    const otrosLimites = obtenerLimites(otroGrupo);
    let dx = otrosLimites.cx - limites.cx;
    let dy = otrosLimites.cy - limites.cy;
    let distancia = Math.hypot(dx, dy);

    if (distancia === 0) {
        dx = 1;
        dy = 0;
        distancia = 1;
    }

    const t = Math.min(
        limites.hw / Math.max(Math.abs(dx / distancia), 0.0001),
        limites.hh / Math.max(Math.abs(dy / distancia), 0.0001)
    );

    return limitarAncla({
        x: (dx / distancia * t) / limites.hw,
        y: (dy / distancia * t) / limites.hh
    });
}

function limitarAncla(ancla) {
    const escala = Math.max(Math.abs(ancla.x), Math.abs(ancla.y), 0.0001);

    return {
        x: ancla.x / escala,
        y: ancla.y / escala
    };
}

function actualizarConexiones() {
    listaConexiones.forEach(function (conexion) {
        const origen = obtenerLimites(conexion.origen);
        const destino = obtenerLimites(conexion.destino);
        const x1 = origen.cx + conexion.anclaOrigen.x * origen.hw;
        const y1 = origen.cy + conexion.anclaOrigen.y * origen.hh;
        const x2 = destino.cx + conexion.anclaDestino.x * destino.hw;
        const y2 = destino.cy + conexion.anclaDestino.y * destino.hh;

        conexion.linea.setAttribute("x1", x1);
        conexion.linea.setAttribute("y1", y1);
        conexion.linea.setAttribute("x2", x2);
        conexion.linea.setAttribute("y2", y2);
        conexion.hitArea.setAttribute("x1", x1);
        conexion.hitArea.setAttribute("y1", y1);
        conexion.hitArea.setAttribute("x2", x2);
        conexion.hitArea.setAttribute("y2", y2);
    });
}

function obtenerLimites(grupo) {
    const figura = grupo.firstElementChild;
    const caja = figura.getBBox();

    const transformacion = grupo.transform.baseVal.consolidate();
    const matriz = transformacion
        ? transformacion.matrix
        : lienzo.createSVGMatrix();

    return {
        cx: matriz.e + caja.x + caja.width / 2,
        cy: matriz.f + caja.y + caja.height / 2,
        hw: caja.width / 2,
        hh: caja.height / 2
    };
}

/* Eliminar conexión o símbolo */

botonEliminar.addEventListener("click", function () {
    if (conexionSeleccionada !== null) {
        const indice = listaConexiones.indexOf(conexionSeleccionada);
        conexionSeleccionada.linea.remove();
        conexionSeleccionada.hitArea.remove();
        listaConexiones.splice(indice, 1);
        conexionSeleccionada = null;
        return;
    }

    if (simboloSeleccionado === null) {
        return;
    }

    const simboloAEliminar = simboloSeleccionado;

    for (let i = listaConexiones.length - 1; i >= 0; i--) {
        const conexion = listaConexiones[i];

        if (
            conexion.origen === simboloAEliminar ||
            conexion.destino === simboloAEliminar
        ) {
            conexion.linea.remove();
            conexion.hitArea.remove();
            listaConexiones.splice(i, 1);
        }
    }

    if (origenConexion === simboloAEliminar) {
        if (conexionPendiente !== null) {
            conexionPendiente.linea.remove();
            conexionPendiente = null;
        }
        origenConexion = null;
        modoConexion = false;
    }

    simboloAEliminar.remove();
    simboloSeleccionado = null;

    actualizarConexiones();
});

function expandirLienzo() {
    const simbolos = lienzo.querySelectorAll(".simbolo");

    let izquierda = Math.min(0, limitesLienzo.x);
    let arriba = Math.min(0, limitesLienzo.y);
    let derecha = Math.max(700, limitesLienzo.x + limitesLienzo.ancho);
    let abajo = Math.max(400, limitesLienzo.y + limitesLienzo.alto);

    simbolos.forEach(function (simbolo) {
        const caja = simbolo.getBBox();
        const transformacion = simbolo.transform.baseVal.consolidate();
        const matriz = transformacion
            ? transformacion.matrix
            : lienzo.createSVGMatrix();

        izquierda = Math.min(izquierda, matriz.e + caja.x - espacioExtra);
        arriba = Math.min(arriba, matriz.f + caja.y - espacioExtra);
        derecha = Math.max(derecha, matriz.e + caja.x + caja.width + espacioExtra);
        abajo = Math.max(abajo, matriz.f + caja.y + caja.height + espacioExtra);
    });

    limitesLienzo.x = izquierda;
    limitesLienzo.y = arriba;
    limitesLienzo.ancho = derecha - izquierda;
    limitesLienzo.alto = abajo - arriba;
    
    lienzo.setAttribute(
        "viewBox",
        `${izquierda} ${arriba} ${limitesLienzo.ancho} ${limitesLienzo.alto}`
    );

    lienzo.style.width = `${limitesLienzo.ancho}px`;
    lienzo.style.height = `${limitesLienzo.alto}px`;
    lienzo.style.maxWidth = "none";

    fondo.setAttribute("x", izquierda);
    fondo.setAttribute("y", arriba);
    fondo.setAttribute("width", limitesLienzo.ancho);
    fondo.setAttribute("height", limitesLienzo.alto);
}

function cambiarPanel(tipo) {
    let panel;
    switch (tipo) {
        case "relleno":
            panel = panelRelleno;
            break;

        case "contorno":
            panel = panelContorno;
            break;

        case "texto":
            panel = panelTexto;
            break;

        default:
            return;
    }

    if (panelActivo === tipo) {
        panel.style.display = "none";
        panelActivo = null;
        return;
    }

    panelRelleno.style.display = "none";
    panelContorno.style.display = "none";
    panelTexto.style.display = "none";

    panel.style.display = "block";
    panelActivo = tipo;
}

btnRelleno.addEventListener("click", function (evento) {
    evento.stopPropagation();
    cambiarPanel("relleno");
});

btnContorno.addEventListener("click", function (evento) {
    evento.stopPropagation();
    cambiarPanel("contorno");
});

btnEditarTexto.addEventListener("click", function (evento) {
    evento.stopPropagation();
    cambiarPanel("texto");
});

btnCerrarContorno.addEventListener("click", function (evento, tipo) {
    evento.stopPropagation();
        panelContorno.style.display = "none";
});

btnCerrarRelleno.addEventListener("click", function (evento, tipo) {
    evento.stopPropagation();
        panelRelleno.style.display = "none";
});

btnCerrarTexto.addEventListener("click", function (evento, tipo) {
    evento.stopPropagation();
    panelTexto.style.display = "none";
});

function habilitarBotonesEdicion() {
    const habilitar = simboloSeleccionado !== null;
    btnRelleno.disabled = !habilitar;
    btnContorno.disabled = !habilitar;
    btnEditarTexto.disabled = !habilitar;
}

function actualizarPanelEditar() {
    if (panelesEditar === null) return;

    const haySeleccion = simboloSeleccionado !== null;
    panelesEditar.forEach(panel => {
        const controles = panel.querySelectorAll(
            "input, select, textarea"
        );

        controles.forEach(control => {
            control.disabled = !haySeleccion;
        });
    });
}

const inputColorContorno = document.getElementById("color-contorno");
const inputColorRelleno = document.getElementById("color-relleno");
const inputColorTexto = document.getElementById("color-texto");
const inputTamanoTexto = document.getElementById("tamano-texto");
const valorTamano = document.getElementById("valor-tamano");

function cambiarColorContorno(color) {
    if (simboloSeleccionado === null) return;
    const figura = simboloSeleccionado.children[0];

    figura.setAttribute("stroke", color);
}

function cambiarColorRelleno(color) {
    if (simboloSeleccionado === null) return;
    const figura = simboloSeleccionado.children[0];

    if (figura.tagName === "line") return;
    figura.style.fill = color;
}

function cambiarColorTexto(color) {
    if (simboloSeleccionado === null) return;
    const texto = simboloSeleccionado.children[1];

    texto.setAttribute("fill", color);
}

function cambiarTamanoTexto(tamano) {
    if (simboloSeleccionado === null) return;
    const texto = simboloSeleccionado.children[1];

    texto.setAttribute("font-size", tamano);
}

inputColorContorno.addEventListener("input", () => {  
    cambiarColorContorno(inputColorContorno.value);
});

inputColorRelleno.addEventListener("input", (evento) => {
    cambiarColorRelleno(inputColorRelleno.value);
});

inputColorTexto.addEventListener("input", (evento) => {
    cambiarColorTexto(inputColorTexto.value);
});

inputTamanoTexto.addEventListener("input", (evento) => {
    const tamano = parseInt(inputTamanoTexto.value, 10);
    cambiarTamanoTexto(tamano);
    valorTamano.textContent = `${tamano} px`;
});
